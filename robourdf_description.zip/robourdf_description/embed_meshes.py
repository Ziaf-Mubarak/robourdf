#!/usr/bin/env python3
"""
embed_meshes.py  -  Fuse a URDF + its STL mesh folder into a single self-contained file.

Usage
-----
    python embed_meshes.py  <input.urdf>  [output.urdf]

    <input.urdf>   Path to your URDF file (meshes folder must be next to it or in
                   the standard <robot>_description/meshes/ layout).
    [output.urdf]  Where to write the result. Defaults to <input>_embedded.urdf

What it does
------------
Every  <mesh filename="package://...">  or  <mesh filename="...stl">
reference is replaced with an inline base64 data URI so the resulting
file works in any URDF viewer that accepts it (gkjohnson/urdf-loaders,
myrobot.cloud, Foxglove, etc.) without needing any companion files.

Isaac Sim / ROS usage
---------------------
For simulation, keep using the original folder-based URDF (package:// refs).
This embedded file is for previewing and sharing only.
"""

import os
import re
import sys
import base64
import struct


# ---------------------------------------------------------------------------
# STL helpers
# ---------------------------------------------------------------------------

def is_binary_stl(data: bytes) -> bool:
    """Return True if the bytes look like a binary STL (not ASCII)."""
    # ASCII STL starts with "solid"
    if data[:5].lower() == b'solid':
        # Could still be binary if the header happens to start with "solid"
        # Check if size matches binary formula
        if len(data) >= 84:
            num_tri = struct.unpack('<I', data[80:84])[0]
            if 84 + num_tri * 50 == len(data):
                return True
        return False
    return True


def stl_to_base64_data_uri(stl_bytes: bytes) -> str:
    """Return a data: URI string for the given STL binary content."""
    b64 = base64.b64encode(stl_bytes).decode('ascii')
    return f"data:application/octet-stream;base64,{b64}"


# ---------------------------------------------------------------------------
# Mesh path resolution
# ---------------------------------------------------------------------------

def find_stl_file(mesh_filename: str, urdf_dir: str) -> str | None:
    """
    Try to locate the STL file on disk, resolving package:// URIs and
    relative paths.  Returns the absolute path, or None if not found.
    """
    filename = mesh_filename.strip()

    # Strip package:// prefix  →  <package_name>/meshes/<file>.stl
    if filename.startswith('package://'):
        filename = filename[len('package://'):]
        # The package root is usually the parent of the urdf/ folder
        # e.g.  robo2_description/meshes/base_link.stl
        # Try: urdf_dir/../<filename>  and  urdf_dir/../../<filename>
        candidates = [
            os.path.join(urdf_dir, '..', filename),
            os.path.join(urdf_dir, '..', '..', filename),
            os.path.join(urdf_dir, filename),
        ]
    elif filename.startswith('data:'):
        return None  # already embedded
    else:
        # Relative or absolute path
        candidates = [
            filename,
            os.path.join(urdf_dir, filename),
            os.path.join(urdf_dir, '..', 'meshes', os.path.basename(filename)),
        ]

    for c in candidates:
        resolved = os.path.normpath(c)
        if os.path.isfile(resolved):
            return resolved

    return None


# ---------------------------------------------------------------------------
# Main embedding logic
# ---------------------------------------------------------------------------

# Matches: <mesh filename="..."/>  or  <mesh filename="..." scale="..."/>
MESH_RE = re.compile(
    r'(<mesh\s[^>]*filename=")([^"]+)(")',
    re.IGNORECASE
)


def embed_urdf(input_path: str, output_path: str) -> None:
    urdf_dir = os.path.dirname(os.path.abspath(input_path))

    with open(input_path, 'r', encoding='utf-8') as f:
        content = f.read()

    cache: dict[str, str] = {}   # path → data URI  (avoids re-encoding duplicates)
    missing: list[str] = []
    replaced = 0

    def replacer(m: re.Match) -> str:
        nonlocal replaced
        prefix, mesh_filename, suffix = m.group(1), m.group(2), m.group(3)

        if mesh_filename.startswith('data:'):
            return m.group(0)   # already embedded

        stl_path = find_stl_file(mesh_filename, urdf_dir)
        if stl_path is None:
            missing.append(mesh_filename)
            return m.group(0)   # leave unchanged

        if stl_path not in cache:
            with open(stl_path, 'rb') as f:
                raw = f.read()
            cache[stl_path] = stl_to_base64_data_uri(raw)

        replaced += 1
        return prefix + cache[stl_path] + suffix

    new_content = MESH_RE.sub(replacer, content)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(new_content)

    print(f"✓  Embedded {replaced} mesh(es) into '{output_path}'")
    file_kb = os.path.getsize(output_path) / 1024
    print(f"   Output size: {file_kb:.1f} KB")

    if missing:
        print(f"\n⚠  Could not find {len(missing)} mesh file(s) — left as-is:")
        for m in missing:
            print(f"   {m}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    input_path = sys.argv[1]
    if not os.path.isfile(input_path):
        print(f"Error: '{input_path}' not found.")
        sys.exit(1)

    if len(sys.argv) >= 3:
        output_path = sys.argv[2]
    else:
        base, ext = os.path.splitext(input_path)
        output_path = base + '_embedded' + ext

    embed_urdf(input_path, output_path)


if __name__ == '__main__':
    main()
